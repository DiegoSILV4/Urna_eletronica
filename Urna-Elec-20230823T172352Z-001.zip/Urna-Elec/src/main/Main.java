
package main;

import VIEW.VOTACAOtela_GUI;



/**
 *
 * @author Diego
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new VOTACAOtela_GUI().setVisible(true);
    }
    
}
