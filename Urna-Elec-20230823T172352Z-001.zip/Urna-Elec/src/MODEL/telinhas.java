/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL;


import VIEW.APURACAO_GUI;
import static VIEW.APURACAO_GUI.telach1;
import static VIEW.APURACAO_GUI.telaju1;
import static VIEW.APURACAO_GUI.telaky3;
import static VIEW.CHAVES_GUI.chaves_votos;
import static VIEW.JULIUS_GUI.julius_votos;
import static VIEW.KYLE_GUI.kyle_votos;

import javax.swing.JOptionPane;


/**
 
 * @author Alunos
 */
public class telinhas {
    
    
    public static void senha(){
        int senha= Integer.parseInt(VIEW.SENHA_GUI.senha.getText());
        
        
        
       if(senha==1234){
           new APURACAO_GUI().setVisible(true);
            telach1.setText(chaves_votos);
            telaju1.setText(julius_votos);
            telaky3.setText(kyle_votos);
           
        }else{
           JOptionPane.showMessageDialog(null, "Senha Inválida");
       
       }
}
}