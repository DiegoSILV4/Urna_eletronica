package VIEW;


import static VIEW.CHAVES_GUI.telach;
import static VIEW.CHAVES_GUI.var1;
import static VIEW.KYLE_GUI.cont1;
import static VIEW.KYLE_GUI.contador;
import static VIEW.KYLE_GUI.kyle_votos;
import static VIEW.VOTACAOtela_GUI.tela;

public class JULIUS_GUI extends javax.swing.JFrame {
    public static String julius_votos="";
    public static int telajus=0;  
    public static int cont2=4;
    public static String var1="";
    public static int contadorj=0;


    public JULIUS_GUI() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        panelImage1 = new org.edisoncor.gui.panel.PanelImage();
        telaju = new javax.swing.JLabel();
        dig2 = new javax.swing.JButton();
        dig3 = new javax.swing.JButton();
        dig5 = new javax.swing.JButton();
        dig6 = new javax.swing.JButton();
        dig7 = new javax.swing.JButton();
        dig8 = new javax.swing.JButton();
        dig9 = new javax.swing.JButton();
        dig0 = new javax.swing.JButton();
        dig1 = new javax.swing.JButton();
        tela4 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        dig4 = new javax.swing.JButton();
        confirma = new javax.swing.JButton();
        corrige = new javax.swing.JButton();
        branco = new javax.swing.JButton();
        panelImage2 = new org.edisoncor.gui.panel.PanelImage();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        panelImage1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMGS/URNA ELETRÔNICA (1).png"))); // NOI18N
        panelImage1.setLayout(null);

        telaju.setFont(new java.awt.Font("Arial", 0, 22)); // NOI18N
        telaju.setText("13");
        telaju.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));
        panelImage1.add(telaju);
        telaju.setBounds(190, 80, 180, 50);

        dig2.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        dig2.setText("2");
        dig2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dig2ActionPerformed(evt);
            }
        });
        panelImage1.add(dig2);
        dig2.setBounds(700, 80, 60, 30);

        dig3.setText("3");
        dig3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dig3ActionPerformed(evt);
            }
        });
        panelImage1.add(dig3);
        dig3.setBounds(770, 80, 60, 30);

        dig5.setText("5");
        dig5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dig5ActionPerformed(evt);
            }
        });
        panelImage1.add(dig5);
        dig5.setBounds(700, 130, 60, 30);

        dig6.setText("6");
        dig6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dig6ActionPerformed(evt);
            }
        });
        panelImage1.add(dig6);
        dig6.setBounds(770, 130, 60, 30);

        dig7.setText("7");
        dig7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dig7ActionPerformed(evt);
            }
        });
        panelImage1.add(dig7);
        dig7.setBounds(630, 180, 60, 30);

        dig8.setText("8");
        dig8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dig8ActionPerformed(evt);
            }
        });
        panelImage1.add(dig8);
        dig8.setBounds(700, 180, 60, 30);

        dig9.setText("9");
        dig9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dig9ActionPerformed(evt);
            }
        });
        panelImage1.add(dig9);
        dig9.setBounds(770, 180, 60, 30);

        dig0.setText("0");
        dig0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dig0ActionPerformed(evt);
            }
        });
        panelImage1.add(dig0);
        dig0.setBounds(700, 230, 60, 30);

        dig1.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        dig1.setText("1");
        dig1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dig1ActionPerformed(evt);
            }
        });
        panelImage1.add(dig1);
        dig1.setBounds(630, 80, 60, 30);

        tela4.setForeground(new java.awt.Color(255, 255, 255));
        panelImage1.add(tela4);
        tela4.setBounds(730, 150, 0, 0);

        jPanel6.setBackground(new java.awt.Color(63, 53, 52));
        jPanel6.setLayout(null);
        panelImage1.add(jPanel6);
        jPanel6.setBounds(570, 350, 110, 0);

        dig4.setText("4");
        dig4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dig4ActionPerformed(evt);
            }
        });
        panelImage1.add(dig4);
        dig4.setBounds(630, 130, 60, 30);

        confirma.setBackground(new java.awt.Color(51, 255, 0));
        confirma.setFont(new java.awt.Font("Arial", 0, 10)); // NOI18N
        confirma.setText("CONFIRMA");
        confirma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmaActionPerformed(evt);
            }
        });
        panelImage1.add(confirma);
        confirma.setBounds(790, 280, 90, 40);

        corrige.setBackground(new java.awt.Color(255, 102, 0));
        corrige.setFont(new java.awt.Font("Arial", 0, 10)); // NOI18N
        corrige.setText("CORRIGIR");
        corrige.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                corrigeActionPerformed(evt);
            }
        });
        panelImage1.add(corrige);
        corrige.setBounds(690, 280, 90, 40);

        branco.setFont(new java.awt.Font("Arial", 0, 10)); // NOI18N
        branco.setText("BRANCO");
        branco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                brancoActionPerformed(evt);
            }
        });
        panelImage1.add(branco);
        branco.setBounds(600, 280, 80, 40);

        panelImage2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMGS/julius-rock.jpg"))); // NOI18N

        javax.swing.GroupLayout panelImage2Layout = new javax.swing.GroupLayout(panelImage2);
        panelImage2.setLayout(panelImage2Layout);
        panelImage2Layout.setHorizontalGroup(
            panelImage2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 120, Short.MAX_VALUE)
        );
        panelImage2Layout.setVerticalGroup(
            panelImage2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        panelImage1.add(panelImage2);
        panelImage2.setBounds(390, 80, 120, 100);

        jLabel2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel2.setText("NOME: JULIUS");
        panelImage1.add(jLabel2);
        jLabel2.setBounds(60, 180, 140, 22);

        jLabel3.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel3.setText("NOME: JULIUS");
        panelImage1.add(jLabel3);
        jLabel3.setBounds(60, 180, 140, 22);

        jLabel4.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel4.setText("PARTIDO: CUPONS E DESCONTOS");
        panelImage1.add(jLabel4);
        jLabel4.setBounds(60, 220, 310, 22);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(panelImage1, javax.swing.GroupLayout.PREFERRED_SIZE, 923, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(panelImage1, javax.swing.GroupLayout.PREFERRED_SIZE, 545, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(900, 500));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void brancoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_brancoActionPerformed
        int votos_brancos=0;
        votos_brancos=votos_brancos+1;
        new MENU_GUI().setVisible(true);
        MODEL.tocador.tocar();
        this.dispose();
    }//GEN-LAST:event_brancoActionPerformed

    private void dig1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dig1ActionPerformed
        
      
    }//GEN-LAST:event_dig1ActionPerformed

    private void dig2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dig2ActionPerformed
  
    }//GEN-LAST:event_dig2ActionPerformed

    private void dig3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dig3ActionPerformed
       
    }//GEN-LAST:event_dig3ActionPerformed

    private void dig5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dig5ActionPerformed
        
    }//GEN-LAST:event_dig5ActionPerformed

    private void dig6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dig6ActionPerformed
        
    }//GEN-LAST:event_dig6ActionPerformed

    private void dig7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dig7ActionPerformed
        
    }//GEN-LAST:event_dig7ActionPerformed

    private void dig8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dig8ActionPerformed
        
    }//GEN-LAST:event_dig8ActionPerformed

    private void dig9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dig9ActionPerformed
       
    }//GEN-LAST:event_dig9ActionPerformed

    private void dig0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dig0ActionPerformed
        
    }//GEN-LAST:event_dig0ActionPerformed

    private void corrigeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_corrigeActionPerformed
        var1="";
        tela.setText("");
        this.dispose();
        new VOTACAOtela_GUI().setVisible(true);
    }//GEN-LAST:event_corrigeActionPerformed

    private void confirmaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmaActionPerformed
        if(cont2==4){
        new VOTACAOtela_GUI().setVisible(true);
        this.dispose();
        contadorj=contadorj+1;
  
        julius_votos= Integer.toString(contadorj);
        MODEL.tocador.tocar();
        }
        
    }//GEN-LAST:event_confirmaActionPerformed

    private void dig4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dig4ActionPerformed
       
    }//GEN-LAST:event_dig4ActionPerformed

    public static void main(String args[]) {
       
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JULIUS_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JULIUS_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JULIUS_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JULIUS_GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JULIUS_GUI().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton branco;
    private javax.swing.JButton confirma;
    private javax.swing.JButton corrige;
    private javax.swing.JButton dig0;
    private javax.swing.JButton dig1;
    private javax.swing.JButton dig2;
    private javax.swing.JButton dig3;
    private javax.swing.JButton dig4;
    private javax.swing.JButton dig5;
    private javax.swing.JButton dig6;
    private javax.swing.JButton dig7;
    private javax.swing.JButton dig8;
    private javax.swing.JButton dig9;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel6;
    private org.edisoncor.gui.panel.PanelImage panelImage1;
    private org.edisoncor.gui.panel.PanelImage panelImage2;
    private javax.swing.JLabel tela4;
    public static javax.swing.JLabel telaju;
    // End of variables declaration//GEN-END:variables
}
